#!/usr/bin/env python3
"""OBDS 1.0.0 release gate.

Validates the release metadata files of this package and proves the package
contains no build or test junk.

This is a package check. It is not an OBDS capability, not a profile and not part
of the 105-case conformance suite.

Run from the package root:

    python reference/release-gate.py
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Concrete expected values for THIS release. The generic schemas stay value-free;
# the fixture lives here.
EXPECTED_SUITE_COUNTS = {
    "foundation": 25,
    "context-delivery": 3,
    "context-assembly": 15,
    "design-space": 18,
    "integration": 15,
    "golden": 6,
    "adversarial": 23,
}
EXPECTED_TOTAL = 105
EXPECTED_RELEASE = "1.0.0"
EXPECTED_STATUS = "stable"
EXPECTED_PUBLIC_SCHEMAS = 21
EXPECTED_PUBLIC_VALUE_SCHEMAS = 6

JUNK_DIRS = {"__pycache__", ".pytest_cache", "__MACOSX", ".ipynb_checkpoints"}
JUNK_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}
JUNK_SUFFIXES = (".pyc", ".pyo", ".swp", ".swo", ".orig", ".rej", ".bak", ".tmp", "~")

failures: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)


def sha256_file(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def find_junk() -> list[str]:
    found = []
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if any(part in JUNK_DIRS for part in path.parts):
            found.append(rel)
        elif path.name in JUNK_NAMES or path.name.endswith(JUNK_SUFFIXES):
            found.append(rel)
    return sorted(set(found))


def validate_schemas(test_result, audit) -> None:
    try:
        from jsonschema import Draft202012Validator
        from referencing import Registry, Resource
    except ImportError as exc:  # pragma: no cover
        failures.append(f"cannot validate release metadata: {exc}")
        return

    schema_dir = ROOT / "release-schemas"
    resources = []
    for name in ("release-test-result.schema.json", "release-audit.schema.json"):
        schema = load(schema_dir / name)
        resources.append((schema["$id"], Resource.from_contents(schema)))
    registry = Registry().with_resources(resources)

    pairs = [
        ("OBDS-1.0.0-TEST-RESULT.json", "release-test-result.schema.json", test_result),
        ("OBDS-1.0.0-FINAL-AUDIT.json", "release-audit.schema.json", audit),
    ]
    for label, schema_name, instance in pairs:
        schema = load(schema_dir / schema_name)
        validator = Draft202012Validator(schema, registry=registry)
        for error in sorted(validator.iter_errors(instance), key=str):
            location = "/".join(str(part) for part in error.path) or "<root>"
            failures.append(f"{label}: {location}: {error.message}")


def main() -> int:
    test_result = load(ROOT / "OBDS-1.0.0-TEST-RESULT.json")
    audit = load(ROOT / "OBDS-1.0.0-FINAL-AUDIT.json")

    validate_schemas(test_result, audit)

    # 1. counts must sum. This is the check that would have caught adversarial=105.
    for label, doc, total_key in (
        ("TEST-RESULT", test_result, "passedCount"),
        ("FINAL-AUDIT", audit, "testsPassed"),
    ):
        counts = doc["suiteCounts"]
        total = doc[total_key]
        check(
            sum(counts.values()) == total,
            f"{label}: sum(suiteCounts)={sum(counts.values())} != {total_key}={total}",
        )
        check(counts == EXPECTED_SUITE_COUNTS, f"{label}: suiteCounts != verified run")
        check(total == EXPECTED_TOTAL, f"{label}: {total_key} != {EXPECTED_TOTAL}")

    # 2. the two metadata files must agree with each other.
    check(test_result["suiteCounts"] == audit["suiteCounts"], "suiteCounts differ between TEST-RESULT and FINAL-AUDIT")
    check(test_result["testOutputHash"] == audit["testOutputHash"], "testOutputHash differs between TEST-RESULT and FINAL-AUDIT")
    check(test_result["release"] == audit["release"] == EXPECTED_RELEASE, "release identity mismatch")
    check(test_result["status"] == audit["status"] == EXPECTED_STATUS, "status is not stable in both files")
    check(test_result["failedCount"] == 0 and audit["testsFailed"] == 0, "declared failures are not zero")

    # 3. the declared hash must be the hash of the actual test output.
    actual = sha256_file(ROOT / "OBDS-1.0.0-TEST-OUTPUT.txt")
    check(test_result["testOutputHash"] == actual, f"testOutputHash != sha256(OBDS-1.0.0-TEST-OUTPUT.txt) {actual}")

    # 4. the test output itself must agree with the declared counts.
    output = (ROOT / "OBDS-1.0.0-TEST-OUTPUT.txt").read_text(encoding="utf-8")
    check(f"TOTAL: {EXPECTED_TOTAL} passed" in output, "test output does not report the declared total")
    check("failed" not in output, "test output reports failures")
    check("error" not in output.lower(), "test output reports errors")
    check("skipped" not in output, "test output reports skipped cases")
    for suite, count in EXPECTED_SUITE_COUNTS.items():
        check(
            re.search(rf"^## {re.escape(suite)}$", output, re.M) is not None,
            f"test output missing suite header {suite}",
        )
        check(f"{count} passed in " in output, f"test output missing '{count} passed' for {suite}")

    # 5. public schema surface.
    schemas = sorted(p.name for p in (ROOT / "schemas").glob("*.json"))
    value_schemas = sorted(p.name for p in (ROOT / "value-schemas").glob("*.json"))
    check(len(schemas) == EXPECTED_PUBLIC_SCHEMAS, f"public schema count {len(schemas)} != {EXPECTED_PUBLIC_SCHEMAS}")
    check(
        len(value_schemas) == EXPECTED_PUBLIC_VALUE_SCHEMAS,
        f"public value schema count {len(value_schemas)} != {EXPECTED_PUBLIC_VALUE_SCHEMAS}",
    )
    check(audit["publicSchemaCount"] == len(schemas), "audit publicSchemaCount != disk")
    check(audit["publicValueSchemaCount"] == len(value_schemas), "audit publicValueSchemaCount != disk")

    index = load(ROOT / "OBDS-1.0.0-SCHEMA-INDEX.json")
    check(sorted(i["file"] for i in index["schemas"]) == schemas, "schema index does not match schemas/")
    check(sorted(i["file"] for i in index["valueSchemas"]) == value_schemas, "schema index does not match value-schemas/")
    ids = [i["id"] for i in index["schemas"]] + [i["id"] for i in index["valueSchemas"]]
    check(len(ids) == len(set(ids)), "duplicate $id in schema index")

    # 6. package junk.
    junk = find_junk()
    check(not junk, f"package contains {len(junk)} junk files: {junk[:10]}")
    check(audit["packageJunkFiles"] == len(junk), f"audit packageJunkFiles={audit['packageJunkFiles']} but found {len(junk)}")

    # 7. no file may present 1.0.0 itself as a pre-release. The scanner cannot be
    #    its own subject, so its own source is excluded.
    pattern = "release" + "[ -]" + "candidate"
    self_path = Path(__file__).resolve()
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".pyc", ".zip"}:
            continue
        if path.resolve() == self_path:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        if re.search(pattern, text, re.I):
            failures.append(f"pre-release status wording in {path.relative_to(ROOT).as_posix()}")

    if failures:
        print("RELEASE GATE: FAIL")
        for item in failures:
            print("  -", item)
        return 1

    print("RELEASE GATE: PASS")
    print(f"  release            {EXPECTED_RELEASE} {EXPECTED_STATUS}")
    print(f"  tests              {EXPECTED_TOTAL} passed / 0 failed / 0 skipped")
    print(f"  suiteCounts sum    {sum(EXPECTED_SUITE_COUNTS.values())}")
    print(f"  public schemas     {len(schemas)} + {len(value_schemas)} value schemas")
    print(f"  package junk files {len(junk)}")
    print(f"  testOutputHash     {actual}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
