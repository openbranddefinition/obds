#!/usr/bin/env python3
"""OBDS 1.0.2 release gate.

Validates the release metadata files of this package and proves the package
contains no build or test junk.

This is a package check. It is not an OBDS capability, not a profile and not part
of the 105-case conformance suite.

Run from the package root:

    python reference/release-gate.py
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Concrete expected values for THIS release. The generic schemas stay value-free;
# the fixture lives here.
EXPECTED_SUITE_COUNTS = {
    "foundation": 27,
    "context-delivery": 3,
    "context-assembly": 15,
    "design-space": 18,
    "integration": 15,
    "golden": 6,
    "adversarial": 23,
}
EXPECTED_TOTAL = 107
EXPECTED_RELEASE = "1.0.2"
EXPECTED_STATUS = "stable"
EXPECTED_PUBLIC_SCHEMAS = 21
EXPECTED_PUBLIC_VALUE_SCHEMAS = 6

# OBDS 1.0.2 is a licensing, packaging and documentation release. The public
# schema surface must stay byte-identical to the frozen 1.0.0 surface, which 1.0.1
# also carried unchanged. This fingerprint is sha256 over the sorted
# "dir/file:sha256" lines of all 27 public contracts, taken from 1.0.0.
FROZEN_SCHEMA_SURFACE = "517683bb3496867daa2346ceb2f7844e46015f926ff757a9c23da90cf1e5f469"

# Normative contract identity against the immediately preceding release. Every
# entry is sha256 of the file as published in spec/1.0.1/. A licensing release
# must not move any of them.
PRIOR_RELEASE = "1.0.1"
PRIOR_CONTRACT_FINGERPRINTS = {
    "capability-registry": "68fb26cc27f0db658b80de805fc0e27ed271c3881b67de18763a620f2e6107b1",
    "schema-index": "6899ccd33e780c54529e17f5e13320d782863e830c0f6648bf10dab337a55b83",
    "publication-map-contracts": "429247482e5f9d70a867e05e7a223f13c39b9a77c457ca5300a49e74a77f150d",
}

# Files that must exist for the licensing position to be self-describing, with the
# sha256 of the two standard licence texts as published by their stewards. A
# release must never ship a modified licence text.
REQUIRED_LICENCE_FILES = {
    "LICENSES/Apache-2.0.txt": "cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30",
    "LICENSES/CC-BY-4.0.txt": "9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411",
}
REQUIRED_LICENCE_DOCS = ("LICENSE.md", "NOTICE", "TRADEMARKS.md", "GOVERNANCE.md", "CONTRIBUTING.md")

# Wording that the 1.0.2 licensing model retires. None of it may survive anywhere
# in the package.
RETIRED_LICENSING_WORDING = (
    "separate commercial licence",
    "commercial licence is required",
    "Free Use",
    "under legal review",
    "grants no right",
    "nothing on this page grants",
    "tooling carve-out",
    "carve-out",
)

JUNK_DIRS = {"__pycache__", ".pytest_cache", "__MACOSX", ".ipynb_checkpoints"}
JUNK_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}
JUNK_SUFFIXES = (".pyc", ".pyo", ".swp", ".swo", ".orig", ".rej", ".bak", ".tmp", "~")

failures: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)


def sha256_file(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def find_junk() -> list[str]:
    found = []
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if any(part in JUNK_DIRS for part in path.parts):
            found.append(rel)
        elif path.name in JUNK_NAMES or path.name.endswith(JUNK_SUFFIXES):
            found.append(rel)
    return sorted(set(found))


def validate_schemas(test_result, audit) -> None:
    try:
        from jsonschema import Draft202012Validator
        from referencing import Registry, Resource
    except ImportError as exc:  # pragma: no cover
        failures.append(f"cannot validate release metadata: {exc}")
        return

    schema_dir = ROOT / "release-schemas"
    resources = []
    for name in ("release-test-result.schema.json", "release-audit.schema.json"):
        schema = load(schema_dir / name)
        resources.append((schema["$id"], Resource.from_contents(schema)))
    registry = Registry().with_resources(resources)

    pairs = [
        ("OBDS-1.0.2-TEST-RESULT.json", "release-test-result.schema.json", test_result),
        ("OBDS-1.0.2-FINAL-AUDIT.json", "release-audit.schema.json", audit),
    ]
    for label, schema_name, instance in pairs:
        schema = load(schema_dir / schema_name)
        validator = Draft202012Validator(schema, registry=registry)
        for error in sorted(validator.iter_errors(instance), key=str):
            location = "/".join(str(part) for part in error.path) or "<root>"
            failures.append(f"{label}: {location}: {error.message}")


def main() -> int:
    test_result = load(ROOT / "OBDS-1.0.2-TEST-RESULT.json")
    audit = load(ROOT / "OBDS-1.0.2-FINAL-AUDIT.json")

    validate_schemas(test_result, audit)

    # 1. counts must sum. This is the check that would have caught adversarial=105.
    for label, doc, total_key in (
        ("TEST-RESULT", test_result, "passedCount"),
        ("FINAL-AUDIT", audit, "testsPassed"),
    ):
        counts = doc["suiteCounts"]
        total = doc[total_key]
        check(
            sum(counts.values()) == total,
            f"{label}: sum(suiteCounts)={sum(counts.values())} != {total_key}={total}",
        )
        check(counts == EXPECTED_SUITE_COUNTS, f"{label}: suiteCounts != verified run")
        check(total == EXPECTED_TOTAL, f"{label}: {total_key} != {EXPECTED_TOTAL}")

    # 2. the two metadata files must agree with each other.
    check(test_result["suiteCounts"] == audit["suiteCounts"], "suiteCounts differ between TEST-RESULT and FINAL-AUDIT")
    check(test_result["testOutputHash"] == audit["testOutputHash"], "testOutputHash differs between TEST-RESULT and FINAL-AUDIT")
    check(test_result["release"] == audit["release"] == EXPECTED_RELEASE, "release identity mismatch")
    check(test_result["status"] == audit["status"] == EXPECTED_STATUS, "status is not stable in both files")
    check(test_result["failedCount"] == 0 and audit["testsFailed"] == 0, "declared failures are not zero")

    # 3. the declared hash must be the hash of the actual test output.
    actual = sha256_file(ROOT / "OBDS-1.0.2-TEST-OUTPUT.txt")
    check(test_result["testOutputHash"] == actual, f"testOutputHash != sha256(OBDS-1.0.2-TEST-OUTPUT.txt) {actual}")

    # 4. the test output itself must agree with the declared counts.
    output = (ROOT / "OBDS-1.0.2-TEST-OUTPUT.txt").read_text(encoding="utf-8")
    check(f"TOTAL: {EXPECTED_TOTAL} passed" in output, "test output does not report the declared total")
    check("failed" not in output, "test output reports failures")
    check("error" not in output.lower(), "test output reports errors")
    check("skipped" not in output, "test output reports skipped cases")
    for suite, count in EXPECTED_SUITE_COUNTS.items():
        check(
            re.search(rf"^## {re.escape(suite)}$", output, re.M) is not None,
            f"test output missing suite header {suite}",
        )
        check(f"{count} passed in " in output, f"test output missing '{count} passed' for {suite}")

    # 5. public schema surface.
    schemas = sorted(p.name for p in (ROOT / "schemas").glob("*.json"))
    value_schemas = sorted(p.name for p in (ROOT / "value-schemas").glob("*.json"))
    check(len(schemas) == EXPECTED_PUBLIC_SCHEMAS, f"public schema count {len(schemas)} != {EXPECTED_PUBLIC_SCHEMAS}")
    check(
        len(value_schemas) == EXPECTED_PUBLIC_VALUE_SCHEMAS,
        f"public value schema count {len(value_schemas)} != {EXPECTED_PUBLIC_VALUE_SCHEMAS}",
    )
    check(audit["publicSchemaCount"] == len(schemas), "audit publicSchemaCount != disk")
    check(audit["publicValueSchemaCount"] == len(value_schemas), "audit publicValueSchemaCount != disk")

    index = load(ROOT / "OBDS-1.0.2-SCHEMA-INDEX.json")
    check(sorted(i["file"] for i in index["schemas"]) == schemas, "schema index does not match schemas/")
    check(sorted(i["file"] for i in index["valueSchemas"]) == value_schemas, "schema index does not match value-schemas/")
    ids = [i["id"] for i in index["schemas"]] + [i["id"] for i in index["valueSchemas"]]
    check(len(ids) == len(set(ids)), "duplicate $id in schema index")

    # 5b. no normative contract change: the public schema surface must equal 1.0.0.
    lines = []
    for directory in ("schemas", "value-schemas"):
        for path in sorted((ROOT / directory).glob("*.json")):
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            lines.append(f"{directory}/{path.name}:{digest}")
    surface = hashlib.sha256("\n".join(lines).encode()).hexdigest()
    check(
        surface == FROZEN_SCHEMA_SURFACE,
        f"public schema surface changed since 1.0.0: {surface} != {FROZEN_SCHEMA_SURFACE}",
    )
    check(
        all(i["id"].startswith("https://openbranddefinition.org/schemas/1.0.0/") for i in index["schemas"]),
        "schema $id no longer points at the 1.0.0 contract",
    )
    check(
        all(i["id"].startswith("https://openbranddefinition.org/value-schemas/1.0.0/") for i in index["valueSchemas"]),
        "value schema $id no longer points at the 1.0.0 contract",
    )

    # 5c. normative contract identity against the previous release.
    def _canon_fingerprint(payload) -> str:
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

    registry = load(ROOT / f"OBDS-{EXPECTED_RELEASE}-CAPABILITY-REGISTRY.json")
    registry = {k: v for k, v in registry.items() if k != "release"}
    _release_model = dict(registry.get("releaseModel", {}))
    _release_model.pop("normativeSpecification", None)  # release filename is packaging
    registry["releaseModel"] = _release_model
    pubmap = load(ROOT / f"OBDS-{EXPECTED_RELEASE}-PUBLICATION-MAP.json")
    actual_contract = {
        "capability-registry": _canon_fingerprint(registry),
        "schema-index": _canon_fingerprint(
            {"schemas": index["schemas"], "valueSchemas": index["valueSchemas"]}
        ),
        "publication-map-contracts": _canon_fingerprint(pubmap["contracts"]),
    }
    for key, expected in PRIOR_CONTRACT_FINGERPRINTS.items():
        check(
            actual_contract[key] == expected,
            f"normative contract moved since {PRIOR_RELEASE}: {key} "
            f"{actual_contract[key]} != {expected}",
        )
    check(
        pubmap["schemaSurfaceFingerprint"] == f"sha256:{FROZEN_SCHEMA_SURFACE}",
        "publication map schemaSurfaceFingerprint does not match the frozen surface",
    )
    check(pubmap["schemaContractVersion"] == "1.0.0", "schema contract version moved")

    # 5d. the licensing position must be complete and unmodified.
    for rel, digest in REQUIRED_LICENCE_FILES.items():
        path = ROOT / rel
        if not path.is_file():
            failures.append(f"missing licence text {rel}")
            continue
        actual_digest = hashlib.sha256(path.read_bytes()).hexdigest()
        check(
            actual_digest == digest,
            f"{rel} is not the unmodified standard licence text: {actual_digest} != {digest}",
        )
    for name in REQUIRED_LICENCE_DOCS:
        check((ROOT / name).is_file(), f"missing {name}")

    # 5e. no retired licensing wording anywhere in the package. Historical
    #     changelog entries describe what was removed, so the changelog is exempt.
    exempt = {f"OBDS-{EXPECTED_RELEASE}-CHANGELOG.md", "reference/release-gate.py"}
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if not path.is_file() or rel in exempt or rel.startswith("LICENSES/"):
            continue
        if path.suffix.lower() in {".pyc", ".zip"}:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for phrase in RETIRED_LICENSING_WORDING:
            if phrase.lower() in text.lower():
                failures.append(f"retired licensing wording {phrase!r} in {rel}")

    # 6. package junk.
    junk = find_junk()
    check(not junk, f"package contains {len(junk)} junk files: {junk[:10]}")
    check(audit["packageJunkFiles"] == len(junk), f"audit packageJunkFiles={audit['packageJunkFiles']} but found {len(junk)}")

    # 7. no file may present 1.0.0 itself as a pre-release. The scanner cannot be
    #    its own subject, so its own source is excluded.
    pattern = "release" + "[ -]" + "candidate"
    self_path = Path(__file__).resolve()
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".pyc", ".zip"}:
            continue
        if path.resolve() == self_path:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        if re.search(pattern, text, re.I):
            failures.append(f"pre-release status wording in {path.relative_to(ROOT).as_posix()}")

    if failures:
        print("RELEASE GATE: FAIL")
        for item in failures:
            print("  -", item)
        return 1

    print("RELEASE GATE: PASS")
    print(f"  release            {EXPECTED_RELEASE} {EXPECTED_STATUS}")
    print(f"  tests              {EXPECTED_TOTAL} passed / 0 failed / 0 skipped")
    print(f"  suiteCounts sum    {sum(EXPECTED_SUITE_COUNTS.values())}")
    print(f"  public schemas     {len(schemas)} + {len(value_schemas)} value schemas")
    print(f"  schema surface     unchanged since 1.0.0 ({FROZEN_SCHEMA_SURFACE[:16]})")
    print(f"  package junk files {len(junk)}")
    print(f"  contract identity  unchanged vs {PRIOR_RELEASE} (registry, schema index, publication map)")
    print(f"  licence texts      unmodified CC BY 4.0 and Apache 2.0")
    print(f"  testOutputHash     {actual}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
