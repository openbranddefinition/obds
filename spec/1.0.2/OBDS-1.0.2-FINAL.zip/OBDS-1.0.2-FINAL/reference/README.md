# OBDS 1.0 Reference Suites

Suites:

- Foundation
- Context Delivery
- Context Assembly
- Design Space
- Integration
- Golden end-to-end
- Adversarial

Run all suites with:

```bash
python run_all.py
```

The Golden suite exercises Manifest, Build Plan, Compiled Brand Context, Context Delivery, Context Assembly, Review and Runtime Decision in one chain.
